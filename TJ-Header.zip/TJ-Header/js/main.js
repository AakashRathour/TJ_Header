$(".menubtn").click(function () {
  $(this).toggleClass("active");
});
